#include <stdio.h>

int main(void) {
    double x = 3.0;
    double y;
    y = 4*x*x + 2*x + 9;
    printf("%f\n", y);
    return 0;
}