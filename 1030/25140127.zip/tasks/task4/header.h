#ifndef YOSHITOSUZUKI
#define YOSHITOSUZUKI


#include <stdio.h>

int g(int);

int g(int x) {
    return x + 1;
}
#define N 10


#endif