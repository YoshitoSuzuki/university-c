#include "header.h"
#include "header.h"
#include "header.h"

int main(void) {
    int y;
    y = g(3);
}