int f(int n) {
    return n * n;
}