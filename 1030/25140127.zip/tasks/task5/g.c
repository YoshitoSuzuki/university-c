int g(int n) {
    return 3 * n + 1;
}