#ifndef HEADER_H

#define HEADER_H
#include <stdio.h>

#define N 10

int f(int);
int g(int);

#endif
